from datetime import timedelta

# JWT Settings
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(days=10) if DEBUG else timedelta(minutes=5),  # 10 days in dev, 5 mins in prod
    'REFRESH_TOKEN_LIFETIME': timedelta(days=30),  # Optional: longer refresh token
    'ROTATE_REFRESH_TOKENS': False,
    'BLACKLIST_AFTER_ROTATION': True,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
    'VERIFYING_KEY': None,
    'AUTH_HEADER_TYPES': ('Bearer',),
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'TOKEN_TYPE_CLAIM': 'token_type',
}

if DEBUG:
    print("WARNING: Using extended JWT token lifetime (10 days) for development")

# IMPORTANT: Add a warning comment for production
"""
WARNING: The current JWT access token lifetime is set to 10 days for development purposes only.
This should be changed to a shorter duration (e.g., 5-15 minutes) in production.
""" 