import base64
import zlib
import json

# Test content
content = b"Hello, this is a test file!\nTesting compression with proper zlib sdjfl kjashdflk jahsdflkj hasdlkfj hasldkfjh aslkdjfh lkjashdflk jashdflkj hasdlkfjh aslkdjfh laskjdfh lksajdhfl kjashdflk jsahdflkj hasdlfkjh aslkdjfh lksadjfh lksjadhfl kjsadhflk jashdflkj ashdflkj sahdlkfj haslkdfj hsalkdjfh lksjdfh lkjsdhfl kjsahdflk jshdlfk jhsldkfj hlskjdhf lkjhsdlkfjh lkasjdhflkj hasdlkjfh aslkdjfh lksadjhfformat.oh gyat oh gyat oh gyat od fdkjhf kljhsdflkjashdflk jhaldksj hflakjsdhflkjsdh lkjhfaslkdj fhlaksjdhf lkjhdlk fjhlskdjfh kjhthis hai hitoh kjhfkj as thiat hfsihd kjhsk this hkdjshf lkjsahdtoihhdslkjf halskjdfh lkatuhsh kjfhaskljdfhlkas thsdhf laskjdfhlk asjdhtjfhalkjsdhfkl"

# Print original size
print(f"Original size: {len(content)} bytes")

# Compress with zlib (using standard settings)
compressed = zlib.compress(content, level=9)  # level 9 for best compression

# Print compressed size
print(f"Compressed size: {len(compressed)} bytes")
print(f"Compression ratio: {(len(compressed) / len(content)) * 100:.2f}%")

# Convert to base64
base64_data = base64.b64encode(compressed).decode('utf-8')

# Print base64 size
print(f"Base64 size: {len(base64_data)} bytes")

# Create the request JSON
request = {
    "share_token": "932dac14-8803-41ca-9cd9-2fc014f43f74",
    "author": "Test User",
    "email": "test@example.com",
    "timestamp": 1716307200,
    "message": "Test commit via Hoppscotch",
    "parent_hash": None,
    "blobs": [
        {
            "path": "test.txt",
            "compressed_data": base64_data
        }
    ]
}

print("\nJSON Request:")
print(json.dumps(request, indent=2))